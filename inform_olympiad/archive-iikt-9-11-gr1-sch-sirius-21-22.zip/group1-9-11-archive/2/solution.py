n1 = int(input())
n2 = int(input())
if n1 % 2 == 1 or (n1 == 0 and n2 % 2 == 1):
    print("No")
else:
    s = (n1 + 2 * n2) // 2
    ans2 = min(s // 2, n2)
    ans1 = s - 2 * ans2
    print("Yes")
    print(ans1, ans2)
