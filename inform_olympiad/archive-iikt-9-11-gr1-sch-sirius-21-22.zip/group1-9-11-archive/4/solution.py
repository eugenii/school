x1, y1 = int(input()), int(input())
x2, y2 = int(input()), int(input())
if (x1 + y1) % 2 != (x2 + y2) % 2:
    print("No")
else:
    print("Yes")
    print(2)
    for i in range(64):
        x3, y3 = i // 8 + 1, i % 8 + 1
        if abs(x1 - x3) == abs(y1 - y3) and abs(x2 - x3) == abs(y2 - y3):
            print(x3, y3)
            break
    print(x2, y2)
