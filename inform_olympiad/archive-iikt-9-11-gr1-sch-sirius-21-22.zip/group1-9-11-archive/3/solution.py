n = int(input())
c = 0

left = 0
x = int(input())

for right in range(1, n):
    y = int(input())
    if x != y:
        c += (right - left) // 3
        x = y
        left = right

print(c + (n - left) // 3)