#include <iostream>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {

    registerTestlibCmd(argc, argv);
    int n1 = inf.readInt();
    int n2 = inf.readInt();

    string sOut = ouf.readWord();
    string sAns = ans.readWord();

    for (auto& c: sOut) {
        c = std::tolower(c);
    }

    for (auto& c: sAns) {
        c = std::tolower(c);
    }

    if (sOut != "no" && sOut != "yes") {
        quitf(_pe, "Wrong format output");
    }
    else if(sOut != sAns){
        quitf(_wa, "User answer is %s, but correct answer is %s", sOut.c_str(), sAns.c_str());
    }
    else if(sOut == "no"){
        quitf(_ok, "Ok");
    }
    else{
        int k1 = ouf.readInt();
        int k2 = ouf.readInt();
        if(k1 + 2*k2 != (n1 + 2*n2) / 2){
            quitf(_wa, "Weights groups are not equal");
        }
        else{
            quitf(_ok, "Ok");
        }
    }


    return 0;
}
