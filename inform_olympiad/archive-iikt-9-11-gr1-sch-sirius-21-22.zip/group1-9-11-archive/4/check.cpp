#include <iostream>
#include <fstream>

#include "testlib.h"

int n;
int input_x1, input_y1, input_x2, input_y2;
std::vector<std::pair<int, int>> way;
std::string s;

inline void ReadAndCheckAnswer() {
  s = ouf.readWord();

  for (auto& c: s) {
    c = std::tolower(c);
  }

  if (s != "no" && s != "yes") {
    quitf(_pe, "Wrong format output");
  }

  if ((input_x1 + input_y1 + input_x2 + input_y2) % 2 == 0) {
    if (s == "no") {
      quitf(_wa, "Wrong answer");
    } else {
      n = ouf.readInt();

      if (n > 100 || n <= 0) {
        quitf(_wa, "Wrong format output");
      }
      way.resize(n);

      for (int i = 0; i < n; ++i) {
        way[i].first = ouf.readInt();
        way[i].second = ouf.readInt();
      }

      // Проверка на корректность координат
      for (int i = 0; i < n; ++i) {
        if (!(way[i].first >= 1 && way[i].first <= 8))
          quitf(_wa, "Wrong cell coordinates");
        if (!(way[i].second >= 1 && way[i].second <= 8))
          quitf(_wa, "Wrong cell coordinates");
      }

      std::pair<int, int> cur = {input_x1, input_y1};

      // Проверка на возможность прыжка
      auto check = [](auto f, auto s) {
        return abs(f.first - s.first) == abs(f.second - s.second);
      };

      for (int i = 0; i < n; ++i) {
        if (!check(cur, way[i]))
          quitf(_wa, "Wrong move");

        cur = way[i];
      }

      // Проверка конечной точки
      if (way.size() == 0 || std::make_pair(input_x2, input_y2) != way.back())
        quitf(_wa, "Wrong end point");
    }
  } else {
    if (s == "yes") {
      quitf(_wa, "Wrong answer");
    }
  }
}

int main(int argc, char* argv[]) {
  registerTestlibCmd(argc, argv);

  input_x1 = inf.readInt();
  input_y1 = inf.readInt();
  input_x2 = inf.readInt();
  input_y2 = inf.readInt();

  ReadAndCheckAnswer();

  quitf(_ok, "");
}

