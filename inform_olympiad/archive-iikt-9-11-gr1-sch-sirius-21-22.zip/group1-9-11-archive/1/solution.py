n = int(input())
d = int(input())
if d != 1:
    n -= 8 - d
print(max(n // 7, 0))

