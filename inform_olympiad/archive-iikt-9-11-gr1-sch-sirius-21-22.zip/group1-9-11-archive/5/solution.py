n = int(input())
ans = 1
x2 = 1
while x2 <= n:
    x3 = x2
    while x3 <= n:
        x5 = x3
        while x5 <= n:
            ans = max(ans, x5)
            x5 *= 5
        x3 *= 3
    x2 *= 2
print(ans)

